import bpy
import threading
from . import ollama_client, utils


class BO_OT_CaptureViewport(bpy.types.Operator):
    bl_idname = "bo.capture_viewport"
    bl_label = "Capturar Viewport"
    bl_description = "Tira um screenshot da viewport 3D e usa como imagem de referência"
    bl_options = {'REGISTER'}

    def execute(self, context):
        import os
        import tempfile

        # Find the first 3D viewport area
        area = None
        for a in context.screen.areas:
            if a.type == 'VIEW_3D':
                area = a
                break

        if area is None:
            self.report({'ERROR'}, "Nenhuma viewport 3D encontrada.")
            return {'CANCELLED'}

        # Ensure the temp directory exists
        temp_dir = tempfile.gettempdir()
        screenshot_path = os.path.join(temp_dir, "blenderollama_viewport.png")

        # Save viewport screenshot using the space_image export API
        try:
            # Use bpy.ops.screen.screenshot_clipboard for copy, but save manually via area region
            region = [r for r in area.regions if r.type == 'WINDOW'][0]
            # Build context override dictionary for the operator
            override = context.copy()
            override['area'] = area
            override['region'] = region
            override['window'] = context.window
            override['screen'] = context.screen

            # Save screenshot to file using the viewport draw callback approach is complex,
            # so we use bpy.ops.screen.screenshot_area which saves active area to path in Blender 5.x
            bpy.ops.screen.screenshot_area(override, filepath=screenshot_path)
            context.scene.bo_image_path = screenshot_path
            self.report({'INFO'}, f"Viewport capturada: {screenshot_path}")
        except Exception as e:
            self.report({'ERROR'}, f"Falha ao capturar viewport: {e}")
            return {'CANCELLED'}
        return {'FINISHED'}


class BO_OT_PasteImagePath(bpy.types.Operator):
    bl_idname = "bo.paste_image_path"
    bl_label = "Colar Caminho da Imagem"
    bl_description = "Cola o caminho absoluto da área de transferência como imagem de referência"
    bl_options = {'REGISTER'}

    def execute(self, context):
        try:
            import subprocess
            # PowerShell to read clipboard text; fallback gracefully on failure
            proc = subprocess.run(
                ["powershell", "-Command", "Get-Clipboard -Raw"],
                capture_output=True, text=True, check=True
            )
            path = proc.stdout.strip().strip('"')
            if not path:
                self.report({'WARNING'}, "Área de transferência vazia.")
                return {'CANCELLED'}
            context.scene.bo_image_path = path
            self.report({'INFO'}, f"Caminho colado: {path}")
        except Exception as e:
            self.report({'ERROR'}, f"Não foi possível colar: {e}")
        return {'FINISHED'}


class BO_OT_ClearImagePath(bpy.types.Operator):
    bl_idname = "bo.clear_image_path"
    bl_label = "Limpar Imagem"
    bl_description = "Remove a imagem de referência do prompt"
    bl_options = {'REGISTER'}

    def execute(self, context):
        context.scene.bo_image_path = ""
        self.report({'INFO'}, "Imagem de referência removida.")
        return {'FINISHED'}


class BO_OT_TestConnection(bpy.types.Operator):
    bl_idname = "bo.test_connection"
    bl_label = "Testar Conexão com Ollama"
    bl_options = {'REGISTER'}

    def execute(self, context):
        try:
            message = ollama_client.check_connection()
            self.report({'INFO'}, f"BenderOllama: {message}")
        except Exception as e:
            self.report({'ERROR'}, f"BenderOllama: {str(e)}")
        return {'FINISHED'}


class BO_OT_RefreshModels(bpy.types.Operator):
    bl_idname = "bo.refresh_models"
    bl_label = "Atualizar Modelos"
    bl_description = "Busca a lista de modelos disponíveis na API configurada"
    bl_options = {'REGISTER'}

    def execute(self, context):
        try:
            models = ollama_client.list_models()
            context.scene.bo_available_models.clear()
            for name in models:
                item = context.scene.bo_available_models.add()
                item.name = name
            if models:
                prefs_model = context.preferences.addons[__package__].preferences.ollama_model
                selected = prefs_model if prefs_model in models else models[0]
                context.scene.bo_selected_model = selected
                self.report({'INFO'}, f"{len(models)} modelos encontrados.")
            else:
                self.report({'WARNING'}, "Nenhum modelo encontrado.")
        except Exception as e:
            self.report({'ERROR'}, f"Erro ao buscar modelos: {e}")
        return {'FINISHED'}


class BO_OT_ExecutePrompt(bpy.types.Operator):
    bl_idname = "bo.execute_prompt"
    bl_label = "Execute Ollama Prompt"
    bl_options = {'REGISTER', 'UNDO'}

    _timer = None
    _thread = None
    _result = None
    _error = None
    _done = False
    _prompt = ""

    def execute(self, context):
        prompt = context.scene.bo_prompt
        if not prompt.strip():
            self.report({'WARNING'}, "Digite um prompt antes de executar.")
            return {'CANCELLED'}

        self._prompt = prompt
        self._result = None
        self._error = None
        self._done = False
        context.scene.bo_is_processing = True
        context.scene.bo_progress = 0.0
        self.report({'INFO'}, f"BenderOllama processando: {prompt}")

        model = context.scene.bo_selected_model or None
        image_path = context.scene.bo_image_path or None
        self._thread = threading.Thread(target=self._generate_in_thread, args=(prompt, model, image_path))
        self._thread.start()

        wm = context.window_manager
        self._timer = wm.event_timer_add(0.1, window=context.window)
        wm.modal_handler_add(self)

        return {'RUNNING_MODAL'}

    def _generate_in_thread(self, prompt, model, image_path):
        try:
            self._result = ollama_client.generate(prompt, model=model, image_path=image_path)
        except Exception as e:
            self._error = str(e)
        finally:
            self._done = True

    def modal(self, context, event):
        if event.type == 'TIMER':
            # Animate progress bar while waiting
            if not self._done:
                context.scene.bo_progress = (context.scene.bo_progress + 0.03) % 1.0
                for area in context.screen.areas:
                    area.tag_redraw()
            else:
                return self._finish(context)
        return {'PASS_THROUGH'}

    def _finish(self, context):
        wm = context.window_manager
        if self._timer:
            wm.event_timer_remove(self._timer)
            self._timer = None

        context.scene.bo_is_processing = False
        context.scene.bo_progress = 0.0

        try:
            if self._error:
                raise Exception(self._error)

            utils.execute_code(self._result, context=context)
            self.add_to_history(context, self._prompt, self._result, success=True)
            self.report({'INFO'}, "BenderOllama: Comando executado!")
        except Exception as e:
            error_message = str(e)
            self.add_to_history(context, self._prompt, error_message, success=False)
            self.report({'ERROR'}, f"BenderOllama errou: {error_message}")
        finally:
            for area in context.screen.areas:
                area.tag_redraw()

        return {'FINISHED'}

    def add_to_history(self, context, prompt, response, success):
        item = context.scene.bo_history.add()
        item.prompt = prompt
        item.response = response
        item.success = success


class BO_OT_RerunHistoryItem(bpy.types.Operator):
    bl_idname = "bo.rerun_history_item"
    bl_label = "Reexecutar Item do Histórico"
    bl_options = {'REGISTER'}

    item_index: bpy.props.IntProperty()

    def execute(self, context):
        scene = context.scene
        idx = self.item_index
        if idx < 0 or idx >= len(scene.bo_history):
            self.report({'WARNING'}, "Item do histórico não encontrado.")
            return {'CANCELLED'}

        item = scene.bo_history[idx]
        context.scene.bo_prompt = item.prompt
        # Execute saved code directly if present, otherwise replay prompt
        code = item.response
        try:
            utils.execute_code(code, context=context)
            item.success = True
            self.report({'INFO'}, "BenderOllama: Comando reexecutado!")
        except Exception as e:
            item.success = False
            self.report({'ERROR'}, f"BenderOllama errou: {e}")
        return {'FINISHED'}


class BO_OT_ClearHistory(bpy.types.Operator):
    bl_idname = "bo.clear_history"
    bl_label = "Limpar Histórico"
    bl_options = {'REGISTER'}

    def execute(self, context):
        context.scene.bo_history.clear()
        context.scene.bo_history_index = -1
        self.report({'INFO'}, "Histórico limpo.")
        return {'FINISHED'}


class BO_OT_OpenPopup(bpy.types.Operator):
    """Open BenderOllama in a floating popup panel."""
    bl_idname = "bo.open_popup"
    bl_label = "BenderOllama"
    bl_options = {'REGISTER'}

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=400)

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        layout.label(text="BenderOllama", icon='CONSOLE')
        layout.prop(scene, "bo_prompt", text="Prompt")

        row = layout.row()
        row.enabled = not scene.bo_is_processing
        row.operator("bo.execute_prompt", text="Executar", icon='LIGHT_DATA')

        if scene.bo_is_processing:
            layout.label(text="Processando...", icon='TEMP')

        if scene.bo_history:
            layout.separator()
            layout.label(text="Últimos comandos:")
            for item in list(scene.bo_history)[-3:]:
                status = "OK" if item.success else "Erro"
                layout.label(text=f"{status}: {item.prompt[:40]}{'...' if len(item.prompt) > 40 else ''}")


classes = [BO_OT_TestConnection, BO_OT_RefreshModels, BO_OT_ExecutePrompt, BO_OT_CaptureViewport, BO_OT_PasteImagePath, BO_OT_ClearImagePath, BO_OT_RerunHistoryItem, BO_OT_ClearHistory, BO_OT_OpenPopup]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
